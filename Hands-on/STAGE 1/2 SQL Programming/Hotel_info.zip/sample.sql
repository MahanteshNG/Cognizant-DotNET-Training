select concat(Hotel_name," is a ", Hotel_type ," hotel") as HOTEL_INFO
from hotel_details
order by HOTEL_INFO desc
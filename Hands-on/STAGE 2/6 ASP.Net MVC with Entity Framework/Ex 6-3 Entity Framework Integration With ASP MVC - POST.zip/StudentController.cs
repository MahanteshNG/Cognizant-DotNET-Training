using ASP_EF_App1.DAL;


using ASP_EF_App1.Models;


using System;


using System.Collections.Generic;


using System.Linq;


using System.Web;


using System.Web.Mvc;



namespace ASP_EF_App1.Controllers //DO NOT change the namespace name


{


 public class StudentController : Controller //DO NOT change the class name


 {


  public ActionResult Index()


  {


   Student std=new Student();


   std.StudentName="Johana";


   std.Department="Art";


   std.PhoneNumber=9876565434;


   std.EnrolledDate=Convert.ToDateTime("06/25/2018");


   return RedirectToAction("AddDetail",std);


  // Implement 'Index' action.


  }


  public ActionResult AddDetail(Student student)


  {


   CollegeContext context=new CollegeContext();


   context.Students.Add(student);


   context.SaveChanges();


   return View("ViewDetails",student);


   // Implement 'AddDetail' action


  }



 }


}

using ASP_App1.Models;

using ASP_App1.Models;


using System;


using System.Collections.Generic;


using System.Linq;


using System.Web;


using System.Web.Mvc;



namespace ASP_App1.Controllers //DO NOT change the namespace name


{


 public class VehicleController : Controller //DO NOT change the class name


 {


  // Implement 'Registration' action


  [HttpGet]


  public ActionResult Registration()


  {


   return View();


  }


  // Implement 'Registration' action as Http POST


  [HttpPost]


  public ActionResult Registration(Registration r)


  {


   ViewBag.CustomerName=r.CustomerName;


   ViewBag.PhoneNumber=r.PhoneNumber;


   ViewBag.VehicleNo=r.VehicleNo;


   ViewBag.City=r.City;


   ViewBag.VehicleModel=r.VehicleModel;


   ViewBag.ServiceType=r.ServiceType;


    


   return View("Confirm");


  }


 }


}


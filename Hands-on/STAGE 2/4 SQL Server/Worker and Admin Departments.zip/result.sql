SELECT a.deptname as "Worker Department", a.location as Location, b.deptname as "Manager Department"
from department a join department b on a.admrdept=b.deptno and a.admrdept!=a.deptno
order by a.deptname;
go
create table orders
(
ord_no numeric(5),
PURCH_AMT decimal(8,2),
ORD_DATE date,
CUSTOMER_ID numeric(5),
SALESMAN_ID numeric(5) foreign key references SALESMAN(SALESMAN_ID)
);
GO
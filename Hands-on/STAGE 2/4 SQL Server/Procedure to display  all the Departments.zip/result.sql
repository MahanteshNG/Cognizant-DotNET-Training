create proc
EmployeesDept(@DeptNo varchar)
as 
begin
select lastname as Name from employee
where workdept='D21'
end
go